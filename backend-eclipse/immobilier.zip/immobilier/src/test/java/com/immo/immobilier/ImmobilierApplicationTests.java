package com.immo.immobilier;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ImmobilierApplicationTests {

	@Test
	void contextLoads() {
	}

}
