package com.immo.immobilier;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ImmobilierApplication {

	public static void main(String[] args) {
		SpringApplication.run(ImmobilierApplication.class, args);
	}

}
